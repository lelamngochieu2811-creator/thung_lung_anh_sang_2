import React from 'react';
import { Trophy, RefreshCw, Star } from 'lucide-react';

interface VictoryProps {
  onRestart: () => void;
}

export const VictoryScreen: React.FC<VictoryProps> = ({ onRestart }) => {
  return (
    <div className="min-h-screen flex items-center justify-center bg-game-bg p-4 font-body">
      <div className="bg-white rounded-3xl shadow-2xl p-8 max-w-2xl w-full text-center border-8 border-eco-green relative overflow-hidden">
        
        <div className="absolute top-0 left-0 w-full h-32 bg-gradient-to-b from-green-100 to-transparent -z-10"></div>

        <div className="mb-8 flex justify-center">
            <div className="relative">
                <Trophy className="w-24 h-24 text-yellow-500 drop-shadow-lg" />
                <Star className="w-10 h-10 text-yellow-400 absolute -top-2 -right-2 animate-spin-slow" />
                <Star className="w-8 h-8 text-yellow-400 absolute top-10 -left-4 animate-pulse" />
            </div>
        </div>

        <h1 className="text-4xl md:text-5xl font-bold text-gray-800 mb-4 font-pixel text-eco-green">
          THÀNH PHỐ XANH!
        </h1>
        
        <p className="text-xl text-gray-600 mb-8">
          Chúc mừng Kỹ sư trưởng! Bạn đã khôi phục Thung Lũng Ánh Sáng, vận hành nhà máy an toàn và giúp người dân sử dụng nhiên liệu hiệu quả.
        </p>

        <div className="grid grid-cols-3 gap-4 mb-8 bg-gray-50 p-6 rounded-xl">
            <div className="text-center">
                <div className="text-3xl font-bold text-yellow-600 mb-1">100%</div>
                <div className="text-xs text-gray-500 uppercase font-bold">Hạnh Phúc</div>
            </div>
            <div className="text-center border-x border-gray-200">
                <div className="text-3xl font-bold text-green-600 mb-1">100%</div>
                <div className="text-xs text-gray-500 uppercase font-bold">Môi Trường</div>
            </div>
            <div className="text-center">
                <div className="text-3xl font-bold text-blue-600 mb-1">MAX</div>
                <div className="text-xs text-gray-500 uppercase font-bold">Năng Lượng</div>
            </div>
        </div>

        <button
          onClick={onRestart}
          className="bg-energy-yellow hover:bg-yellow-500 text-white font-bold py-4 px-8 rounded-full text-xl flex items-center justify-center gap-2 mx-auto transition-transform hover:scale-105 shadow-lg"
        >
          <RefreshCw className="w-6 h-6" />
          CHƠI LẠI
        </button>
      </div>
    </div>
  );
};
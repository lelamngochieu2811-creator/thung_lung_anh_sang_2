import React, { useState } from 'react';
import { Play, User, MailOpen } from 'lucide-react';

interface IntroScreenProps {
  onStart: (name: string) => void;
}

export const IntroScreen: React.FC<IntroScreenProps> = ({ onStart }) => {
  const [name, setName] = useState('');
  const [showLetter, setShowLetter] = useState(false);

  const handleNameSubmit = () => {
    if (name.trim()) {
      setShowLetter(true);
    }
  };

  if (showLetter) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen bg-game-bg p-4 font-body animate-fade-in">
        <div className="bg-[#f4e4bc] p-6 md:p-10 rounded-sm shadow-2xl max-w-2xl w-full border-8 border-[#8B4513] relative transform rotate-1">
            {/* Stamp or decoration */}
            <div className="absolute top-4 right-4 opacity-40">
               <MailOpen className="w-16 h-16 text-[#8B4513]" />
            </div>

            <h2 className="text-3xl font-bold text-[#5D4037] mb-8 font-pixel border-b-2 border-[#5D4037] pb-2 inline-block">THƯ TỪ ÔNG NỘI</h2>
            
            <div className="text-[#4E342E] leading-relaxed text-lg md:text-xl space-y-6 font-letter italic text-justify">
              <p>Chào cháu yêu quý <strong>{name}</strong>,</p>
              
              <p>
                Ta nghe tin cháu đã tốt nghiệp kỹ sư năng lượng loại xuất sắc. Ta rất tự hào!
              </p>
              
              <p>
                Thung Lũng Ánh Sáng từng là nơi rực rỡ nhất vùng, nhưng nay đang thiếu hụt nhiên liệu trầm trọng. 
                Máy móc đình trệ, người dân lo âu vì không biết cách sử dụng gas và than an toàn.
              </p>
              
              <p>
                Ta đã già yếu, không còn đủ sức để leo tháp lọc dầu hay xuống hầm mỏ nữa. 
                Nay ta trao lại quyền quản lý thung lũng cho cháu.
              </p>
              
              <p>
                Hãy dùng kiến thức Hóa học của mình để khai thác tài nguyên, chế biến nhiên liệu và giúp bà con an cư lạc nghiệp nhé.
              </p>
              
              <div className="pt-4">
                <p className="font-bold">Ông tin ở cháu!</p>
                <p className="text-right mt-2 text-2xl font-pixel">- Ông Nội -</p>
              </div>
            </div>

            <div className="mt-10 flex justify-center">
              <button
                onClick={() => onStart(name)}
                className="bg-[#8B4513] hover:bg-[#5D4037] text-[#f4e4bc] font-bold py-4 px-10 rounded-lg shadow-xl flex items-center gap-3 transform transition-transform hover:scale-105 active:scale-95 border-2 border-[#3E2723] text-xl"
              >
                <Play className="w-6 h-6" />
                CHÁU ĐÃ SẴN SÀNG!
              </button>
            </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-game-bg p-4 text-center font-body animate-fade-in">
      <div className="bg-white p-8 rounded-2xl shadow-xl max-w-md w-full border-4 border-energy-yellow">
        <h1 className="text-4xl md:text-5xl font-bold text-gray-800 mb-2 font-pixel text-energy-yellow drop-shadow-sm">
          THUNG LŨNG
          <br />
          ÁNH SÁNG
        </h1>
        <h2 className="text-xl text-gray-600 mb-6 font-bold">Hành Trình Nhiên Liệu</h2>
        
        <p className="text-gray-600 mb-8 text-sm leading-relaxed">
          Chào mừng kỹ sư năng lượng trẻ tuổi! Thung lũng đang cần bạn khôi phục năng lượng, 
          xây dựng nhà máy và mang lại ánh sáng cho thị trấn một cách an toàn và tiết kiệm.
        </p>

        <div className="space-y-4">
          <div className="relative">
            <User className="absolute left-3 top-3 text-gray-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Nhập tên kỹ sư..."
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full pl-10 pr-4 py-3 border-2 border-gray-200 rounded-xl focus:outline-none focus:border-energy-yellow font-bold text-lg"
            />
          </div>

          <button
            onClick={handleNameSubmit}
            disabled={!name.trim()}
            className="w-full bg-energy-yellow hover:bg-yellow-500 text-white font-bold py-3 px-6 rounded-xl transition-all flex items-center justify-center gap-2 text-lg disabled:opacity-50 disabled:cursor-not-allowed shadow-lg transform active:scale-95"
          >
            <Play className="w-6 h-6" />
            TIẾP TỤC
          </button>
        </div>
      </div>
      <p className="mt-8 text-xs text-gray-400 font-pixel">Phiên bản Giáo dục KHTN 9</p>
    </div>
  );
};
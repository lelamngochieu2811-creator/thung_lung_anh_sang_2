import React, { useState, useEffect } from 'react';
import { CheckCircle, AlertCircle, Hammer } from 'lucide-react';

interface Phase1Props {
  onComplete: () => void;
}

type LayerType = 'GAS' | 'OIL' | 'WATER' | 'UNKNOWN';

interface Layer {
  id: string;
  correctType: LayerType;
  currentType: LayerType | null;
  visualColor: string;
  description: string;
}

export const Phase1Mining: React.FC<Phase1Props> = ({ onComplete }) => {
  const [selectedLabel, setSelectedLabel] = useState<LayerType | null>(null);
  const [layers, setLayers] = useState<Layer[]>([
    { id: 'l1', correctType: 'GAS', currentType: null, visualColor: 'bg-gray-200 opacity-80', description: 'Lớp trên cùng: Mờ ảo, màu trắng đục' },
    { id: 'l2', correctType: 'OIL', currentType: null, visualColor: 'bg-oil-brown', description: 'Lớp giữa: Màu nâu đen, sánh đặc' },
    { id: 'l3', correctType: 'WATER', currentType: null, visualColor: 'bg-blue-700', description: 'Lớp đáy: Xanh thẫm, vị mặn' },
  ]);
  const [message, setMessage] = useState<string>("Kéo thả hoặc chọn nhãn rồi bấm vào lớp địa chất tương ứng!");
  const [isComplete, setIsComplete] = useState(false);

  const handleLayerClick = (layerId: string) => {
    if (!selectedLabel) return;

    setLayers(prev => prev.map(layer => {
      if (layer.id === layerId) {
        return { ...layer, currentType: selectedLabel };
      }
      return layer;
    }));
    setSelectedLabel(null);
  };

  useEffect(() => {
    const allCorrect = layers.every(l => l.currentType === l.correctType);
    if (allCorrect && !isComplete) {
      setIsComplete(true);
      setMessage("CHÍNH XÁC! Bạn đã tìm thấy mỏ dầu và khí thiên nhiên!");
      setTimeout(onComplete, 2500);
    }
  }, [layers, isComplete, onComplete]);

  return (
    <div className="flex flex-col items-center w-full max-w-4xl mx-auto p-4 pt-20 animate-fade-in">
      <div className="bg-white p-6 rounded-xl shadow-lg w-full mb-6">
        <div className="flex items-center gap-3 mb-4 border-b pb-4">
           <Hammer className="text-oil-brown w-8 h-8" />
           <div>
             <h2 className="text-2xl font-bold text-gray-800 font-pixel">GIAI ĐOẠN 1: KHAI PHÁ TÀI NGUYÊN</h2>
             <p className="text-gray-600 text-sm">Xác định đúng vị trí các lớp tài nguyên dưới lòng đất.</p>
           </div>
        </div>

        <div className="flex flex-col md:flex-row gap-8">
          {/* Tools / Labels */}
          <div className="flex flex-col gap-4 w-full md:w-1/3">
            <p className="font-bold text-gray-700">1. Chọn Nhãn:</p>
            <button
              onClick={() => setSelectedLabel('GAS')}
              className={`p-4 rounded-lg border-2 font-bold transition-all text-left relative ${selectedLabel === 'GAS' ? 'bg-gray-200 border-gray-500 shadow-inner' : 'bg-white border-gray-300 hover:bg-gray-50'}`}
            >
               Lớp Khí (Gas) <br/>
               <span className="text-xs font-normal text-gray-500">Thành phần chính: Methane</span>
               {layers.find(l => l.currentType === 'GAS') && <CheckCircle className="absolute right-2 top-1/2 -translate-y-1/2 text-green-500 w-6 h-6" />}
            </button>
            <button
              onClick={() => setSelectedLabel('OIL')}
              className={`p-4 rounded-lg border-2 font-bold transition-all text-left relative ${selectedLabel === 'OIL' ? 'bg-orange-100 border-orange-500 shadow-inner' : 'bg-white border-gray-300 hover:bg-gray-50'}`}
            >
               Lớp Dầu Lỏng <br/>
               <span className="text-xs font-normal text-gray-500">Màu nâu đen, nhiều năng lượng</span>
               {layers.find(l => l.currentType === 'OIL') && <CheckCircle className="absolute right-2 top-1/2 -translate-y-1/2 text-green-500 w-6 h-6" />}
            </button>
            <button
              onClick={() => setSelectedLabel('WATER')}
              className={`p-4 rounded-lg border-2 font-bold transition-all text-left relative ${selectedLabel === 'WATER' ? 'bg-blue-100 border-blue-500 shadow-inner' : 'bg-white border-gray-300 hover:bg-gray-50'}`}
            >
               Lớp Nước Mặn <br/>
               <span className="text-xs font-normal text-gray-500">Nặng nhất, chìm dưới đáy</span>
               {layers.find(l => l.currentType === 'WATER') && <CheckCircle className="absolute right-2 top-1/2 -translate-y-1/2 text-green-500 w-6 h-6" />}
            </button>
          </div>

          {/* Geological Cross Section */}
          <div className="w-full md:w-2/3 bg-[#8B4513] p-4 rounded-xl border-4 border-[#5D4037] relative overflow-hidden shadow-inner">
            <p className="text-white/80 font-pixel mb-2 text-center">--- BỀ MẶT ĐẤT LIỀN ---</p>
            
            <div className="flex flex-col gap-1 h-[400px] w-full bg-[#D2B48C] p-4 rounded-lg">
                {layers.map((layer) => (
                  <div
                    key={layer.id}
                    onClick={() => handleLayerClick(layer.id)}
                    className={`flex-1 w-full rounded-md border-2 border-dashed border-white/30 transition-all cursor-pointer relative flex items-center justify-center group ${layer.currentType ? layer.visualColor : 'bg-[#DEB887]'}`}
                  >
                    {!layer.currentType && (
                      <span className="text-white/60 font-bold group-hover:text-white font-pixel text-lg">? Đặt nhãn vào đây</span>
                    )}
                    {layer.currentType && (
                      <div className="bg-white/90 px-4 py-2 rounded-full shadow-md font-bold text-gray-800 flex items-center gap-2">
                         {layer.currentType === 'GAS' && "☁️ LỚP KHÍ"}
                         {layer.currentType === 'OIL' && "🛢️ LỚP DẦU"}
                         {layer.currentType === 'WATER' && "💧 LỚP NƯỚC"}
                      </div>
                    )}
                    {/* Visual Decoration */}
                    {layer.id === 'l1' && layer.currentType === 'GAS' && <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/clouds.png')] opacity-30 pointer-events-none"></div>}
                    {layer.id === 'l2' && layer.currentType === 'OIL' && <div className="absolute inset-0 flex justify-center items-center opacity-20 pointer-events-none text-4xl">🫧</div>}
                  </div>
                ))}
            </div>
          </div>
        </div>

        <div className={`mt-6 p-4 rounded-lg flex items-center gap-3 ${isComplete ? 'bg-green-100 text-green-800 border border-green-300' : 'bg-blue-50 text-blue-800 border border-blue-200'}`}>
          {isComplete ? <CheckCircle className="w-6 h-6" /> : <AlertCircle className="w-6 h-6" />}
          <p className="font-bold">{message}</p>
        </div>
      </div>
    </div>
  );
};
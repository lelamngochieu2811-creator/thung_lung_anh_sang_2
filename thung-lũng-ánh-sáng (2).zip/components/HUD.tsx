import React from 'react';
import { Coins, Heart, Leaf } from 'lucide-react';
import { GameState } from '../types';

interface HUDProps {
  state: GameState;
}

export const HUD: React.FC<HUDProps> = ({ state }) => {
  return (
    <div className="fixed top-0 left-0 right-0 bg-white/90 backdrop-blur-sm shadow-md z-50 px-4 py-2 border-b-4 border-gray-200">
      <div className="max-w-5xl mx-auto flex justify-between items-center">
        <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center border-2 border-blue-300">
             <span className="font-pixel font-bold text-blue-600 text-xl">{state.playerName.charAt(0).toUpperCase()}</span>
            </div>
            <span className="hidden md:inline font-bold text-gray-700 font-pixel">{state.playerName}</span>
        </div>

        <div className="flex items-center gap-4 md:gap-8">
          <div className="flex items-center gap-1 md:gap-2 text-yellow-600 font-bold bg-yellow-50 px-3 py-1 rounded-full border border-yellow-200">
            <Coins className="w-5 h-5 fill-current" />
            <span className="font-pixel text-lg">{state.gold}</span>
          </div>

          <div className="flex items-center gap-1 md:gap-2 text-pink-600 font-bold bg-pink-50 px-3 py-1 rounded-full border border-pink-200">
            <Heart className="w-5 h-5 fill-current" />
            <span className="font-pixel text-lg">{state.happiness}%</span>
          </div>

          <div className="flex items-center gap-1 md:gap-2 text-green-600 font-bold bg-green-50 px-3 py-1 rounded-full border border-green-200">
            <Leaf className="w-5 h-5 fill-current" />
            <span className="font-pixel text-lg">{state.environment}%</span>
          </div>
        </div>
      </div>
    </div>
  );
};
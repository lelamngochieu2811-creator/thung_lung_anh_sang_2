import React, { useState } from 'react';
import { AlertTriangle, Wind, Hammer, ShieldCheck, Check } from 'lucide-react';
import { TOWN_PROBLEMS } from '../constants';
import { ToolType, TownProblem } from '../types';

interface Phase3Props {
  onComplete: () => void;
}

export const Phase3Town: React.FC<Phase3Props> = ({ onComplete }) => {
  const [problems, setProblems] = useState<TownProblem[]>(TOWN_PROBLEMS);
  const [selectedTool, setSelectedTool] = useState<ToolType | null>(null);
  const [selectedProblemId, setSelectedProblemId] = useState<number | null>(null);
  const [dialogue, setDialogue] = useState<string>("Chọn một công cụ, sau đó bấm vào tình huống cần xử lý.");

  const tools = [
    { type: ToolType.FAN, name: 'Quạt Gió (Oxy)', icon: <Wind className="w-6 h-6" />, desc: 'Cung cấp thêm không khí' },
    { type: ToolType.HAMMER, name: 'Búa Đập', icon: <Hammer className="w-6 h-6" />, desc: 'Tăng diện tích tiếp xúc' },
    { type: ToolType.VALVE, name: 'Van An Toàn', icon: <ShieldCheck className="w-6 h-6" />, desc: 'Ngắt gas/Ngăn rò rỉ' },
    { type: ToolType.WARNING, name: 'Cảnh Báo', icon: <AlertTriangle className="w-6 h-6" />, desc: 'Cảnh báo nguy hiểm' },
  ];

  const handleFixAttempt = (problemId: number) => {
    if (!selectedTool) {
      setDialogue("Hãy chọn một công cụ trong hộp đồ nghề trước!");
      return;
    }

    const problem = problems.find(p => p.id === problemId);
    if (!problem) return;

    if (problem.correctTool === selectedTool) {
      setProblems(prev => prev.map(p => p.id === problemId ? { ...p, isSolved: true } : p));
      setDialogue(problem.dialogueSuccess);
      
      // Check completion
      const solvedCount = problems.filter(p => p.isSolved).length + 1; // +1 because state update is pending
      if (solvedCount === problems.length) {
         setTimeout(onComplete, 3000);
      }
    } else {
      setDialogue(problem.dialogueFail);
    }
    
    setSelectedTool(null);
  };

  return (
    <div className="flex flex-col items-center w-full max-w-6xl mx-auto p-4 pt-20 animate-fade-in pb-32">
       <div className="flex items-center gap-3 mb-6 bg-white p-4 rounded-xl shadow w-full">
        <ShieldCheck className="text-green-600 w-8 h-8" />
        <div>
          <h2 className="text-2xl font-bold text-gray-800 font-pixel">GIAI ĐOẠN 3: THỊ TRẤN AN TOÀN</h2>
          <p className="text-gray-600 text-sm">Sử dụng công cụ đúng cách để giải quyết các vấn đề an toàn nhiên liệu.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 w-full mb-8">
        {problems.map(problem => (
          <button
            key={problem.id}
            onClick={() => handleFixAttempt(problem.id)}
            disabled={problem.isSolved}
            className={`p-6 rounded-xl border-4 text-left transition-all relative overflow-hidden group
              ${problem.isSolved 
                ? 'bg-green-100 border-green-400 opacity-80' 
                : 'bg-red-50 border-red-200 hover:border-red-400 hover:shadow-lg'}
            `}
          >
            <div className="flex justify-between items-start">
              <h3 className="font-bold text-xl text-gray-800 mb-2">{problem.title}</h3>
              {problem.isSolved ? <Check className="text-green-600 w-8 h-8" /> : <AlertTriangle className="text-red-500 w-8 h-8 animate-pulse" />}
            </div>
            <p className="text-gray-600">{problem.description}</p>
            {!problem.isSolved && (
              <div className="mt-4 bg-white/50 p-2 rounded text-sm text-red-600 font-bold">
                Cần xử lý ngay!
              </div>
            )}
          </button>
        ))}
      </div>

      {/* Dialogue Box */}
      <div className="w-full bg-gray-800 text-white p-4 rounded-lg mb-4 shadow-lg border-l-4 border-energy-yellow">
        <span className="font-pixel text-yellow-400 mr-2">KỸ SƯ TRƯỞNG:</span>
        {dialogue}
      </div>

      {/* Toolbox (Sticky Bottom) */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t-4 border-gray-300 p-4 shadow-[0_-5px_20px_rgba(0,0,0,0.1)]">
        <div className="max-w-4xl mx-auto flex flex-col md:flex-row items-center gap-4">
           <h4 className="font-pixel text-xl font-bold text-gray-500 whitespace-nowrap">HỘP ĐỒ NGHỀ:</h4>
           <div className="flex gap-2 overflow-x-auto w-full pb-2 md:pb-0">
             {tools.map(tool => (
               <button
                 key={tool.type}
                 onClick={() => setSelectedTool(tool.type)}
                 className={`flex flex-col items-center justify-center p-3 min-w-[100px] rounded-lg border-2 transition-all
                   ${selectedTool === tool.type ? 'bg-blue-100 border-blue-600 text-blue-800 scale-105' : 'bg-gray-50 border-gray-200 hover:bg-gray-100'}
                 `}
               >
                 {tool.icon}
                 <span className="font-bold text-sm mt-1">{tool.name}</span>
               </button>
             ))}
           </div>
        </div>
      </div>

    </div>
  );
};
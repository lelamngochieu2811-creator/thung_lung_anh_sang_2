import React, { useState, useEffect } from 'react';
import { Factory, Truck, Plane, Flame, ChefHat, Construction } from 'lucide-react';
import { ResourceType } from '../types';

interface Phase2Props {
  onComplete: () => void;
}

interface ProductSlot {
  id: number;
  correctProduct: ResourceType;
  currentProduct: ResourceType | null;
  temperature: string;
  label: string;
  color: string;
}

interface CustomerOrder {
  id: number;
  customer: string;
  icon: React.ReactNode;
  neededProduct: ResourceType;
  dialogue: string;
}

const PRODUCTS = [
  { type: ResourceType.LPG, label: 'Khí Hóa Lỏng (LPG)', color: 'bg-blue-200' },
  { type: ResourceType.GASOLINE, label: 'Xăng (Gasoline)', color: 'bg-yellow-300' },
  { type: ResourceType.KEROSENE, label: 'Dầu Hỏa (Kerosene)', color: 'bg-orange-300' },
  { type: ResourceType.DIESEL, label: 'Dầu Diesel', color: 'bg-orange-600 text-white' },
  { type: ResourceType.ASPHALT, label: 'Nhựa Đường', color: 'bg-gray-900 text-white' },
];

export const Phase2Refinery: React.FC<Phase2Props> = ({ onComplete }) => {
  // Sub-phase: 'TOWER' (Building the tower) or 'ORDERS' (Serving customers)
  const [subPhase, setSubPhase] = useState<'TOWER' | 'ORDERS'>('TOWER');
  const [selectedProduct, setSelectedProduct] = useState<ResourceType | null>(null);
  const [towerSlots, setTowerSlots] = useState<ProductSlot[]>([
    { id: 1, correctProduct: ResourceType.LPG, currentProduct: null, temperature: '< 20°C', label: 'Tầng Thượng', color: 'bg-blue-50' },
    { id: 2, correctProduct: ResourceType.GASOLINE, currentProduct: null, temperature: '70°C', label: 'Tầng Cao', color: 'bg-yellow-50' },
    { id: 3, correctProduct: ResourceType.KEROSENE, currentProduct: null, temperature: '170°C', label: 'Tầng Giữa', color: 'bg-orange-50' },
    { id: 4, correctProduct: ResourceType.DIESEL, currentProduct: null, temperature: '270°C', label: 'Tầng Thấp', color: 'bg-red-50' },
    { id: 5, correctProduct: ResourceType.ASPHALT, currentProduct: null, temperature: '> 400°C', label: 'Đáy Tháp', color: 'bg-gray-200' },
  ]);

  // Order logic
  const [currentOrderIndex, setCurrentOrderIndex] = useState(0);
  const [feedback, setFeedback] = useState("");

  const orders: CustomerOrder[] = [
    { id: 1, customer: "Bác Nông Dân", icon: <Truck className="w-8 h-8 text-green-600" />, neededProduct: ResourceType.DIESEL, dialogue: "Máy cày của tôi cần nhiên liệu mạnh mẽ!" },
    { id: 2, customer: "Chị Shipper", icon: <div className="font-bold text-xl">🏍️</div>, neededProduct: ResourceType.GASOLINE, dialogue: "Xe máy tôi hết nhiên liệu rồi!" },
    { id: 3, customer: "Phi Công", icon: <Plane className="w-8 h-8 text-blue-600" />, neededProduct: ResourceType.KEROSENE, dialogue: "Máy bay phản lực cần nhiên liệu tinh khiết để cất cánh." },
    { id: 4, customer: "Bà Nội Trợ", icon: <ChefHat className="w-8 h-8 text-pink-600" />, neededProduct: ResourceType.LPG, dialogue: "Bếp gas nhà tôi cần thay bình mới." },
    { id: 5, customer: "Đội Làm Đường", icon: <Construction className="w-8 h-8 text-gray-700" />, neededProduct: ResourceType.ASPHALT, dialogue: "Chúng tôi cần vật liệu để trải nhựa con đường này." },
  ];

  const handleTowerClick = (slotId: number) => {
    if (!selectedProduct) return;
    setTowerSlots(prev => prev.map(slot => 
      slot.id === slotId ? { ...slot, currentProduct: selectedProduct } : slot
    ));
    setSelectedProduct(null);
  };

  useEffect(() => {
    if (subPhase === 'TOWER') {
      const isTowerComplete = towerSlots.every(s => s.currentProduct === s.correctProduct);
      if (isTowerComplete) {
        setFeedback("Hoàn hảo! Tháp chưng cất đã hoạt động. Hãy phân phối nhiên liệu!");
        setTimeout(() => {
          setSubPhase('ORDERS');
          setFeedback("Khách hàng đang đợi!");
        }, 2000);
      }
    }
  }, [towerSlots, subPhase]);

  const handleOrderSubmit = (productType: ResourceType) => {
    const currentOrder = orders[currentOrderIndex];
    if (productType === currentOrder.neededProduct) {
      setFeedback("Chính xác! +20 Vàng");
      if (currentOrderIndex < orders.length - 1) {
        setTimeout(() => {
          setCurrentOrderIndex(prev => prev + 1);
          setFeedback("");
        }, 1000);
      } else {
        setTimeout(onComplete, 1500);
      }
    } else {
      setFeedback("Sai rồi! Loại nhiên liệu này không phù hợp.");
    }
  };

  return (
    <div className="flex flex-col items-center w-full max-w-5xl mx-auto p-4 pt-20 animate-fade-in">
      
      <div className="flex items-center gap-3 mb-6 bg-white p-4 rounded-xl shadow w-full">
        <Factory className="text-purple-600 w-8 h-8" />
        <div>
          <h2 className="text-2xl font-bold text-gray-800 font-pixel">GIAI ĐOẠN 2: NHÀ MÁY LỌC DẦU</h2>
          <p className="text-gray-600 text-sm">
            {subPhase === 'TOWER' ? "Sắp xếp sản phẩm vào tháp chưng cất theo nhiệt độ sôi." : "Phân phối nhiên liệu đúng nhu cầu."}
          </p>
        </div>
      </div>

      {subPhase === 'TOWER' && (
        <div className="flex flex-col md:flex-row gap-8 w-full">
           {/* Product Palette */}
           <div className="flex flex-col gap-2 w-full md:w-1/3">
             <h3 className="font-bold mb-2">Kho Sản Phẩm:</h3>
             {PRODUCTS.map(p => (
               <button
                 key={p.type}
                 onClick={() => setSelectedProduct(p.type)}
                 className={`p-3 rounded-lg font-bold border-2 transition-all text-left ${selectedProduct === p.type ? 'ring-2 ring-purple-500 scale-105' : ''} ${p.color} border-black/10`}
               >
                 {p.label}
               </button>
             ))}
             <div className="mt-4 text-sm text-gray-500 bg-white p-2 rounded border">
               💡 Gợi ý: Khí nhẹ nhất ở trên, nhựa đường nặng nhất ở đáy.
             </div>
           </div>

           {/* Distillation Tower */}
           <div className="w-full md:w-2/3 bg-gradient-to-b from-blue-50 via-orange-50 to-red-100 p-6 rounded-t-full border-x-4 border-t-4 border-gray-400 relative shadow-xl min-h-[500px] flex flex-col justify-end">
              <div className="absolute -right-12 top-10 bottom-10 w-8 bg-gray-200 rounded border border-gray-400 flex flex-col items-center justify-between py-4">
                 <span className="text-blue-500 font-bold text-xs">LẠNH</span>
                 <div className="w-2 h-full bg-gradient-to-b from-blue-400 to-red-600 rounded"></div>
                 <span className="text-red-600 font-bold text-xs">NÓNG</span>
              </div>
              
              <div className="flex flex-col gap-2 w-full z-10">
                {towerSlots.map(slot => (
                  <div 
                    key={slot.id}
                    onClick={() => handleTowerClick(slot.id)}
                    className={`h-20 w-full border-b-4 border-gray-300/50 flex items-center justify-between px-6 cursor-pointer transition-colors relative
                      ${slot.currentProduct === slot.correctProduct ? 'bg-green-500/20' : (slot.currentProduct ? 'bg-red-500/20' : '')}
                    `}
                  >
                    <div className="flex flex-col">
                      <span className="font-pixel text-gray-500 text-sm">{slot.temperature}</span>
                      <span className="font-bold text-gray-700">{slot.label}</span>
                    </div>
                    
                    <div className={`px-4 py-2 rounded font-bold shadow-sm min-w-[150px] text-center
                      ${slot.currentProduct ? PRODUCTS.find(p => p.type === slot.currentProduct)?.color : 'bg-white border border-dashed border-gray-400 text-gray-400'}
                    `}>
                       {slot.currentProduct ? PRODUCTS.find(p => p.type === slot.currentProduct)?.label : "Trống"}
                    </div>
                  </div>
                ))}
              </div>
           </div>
        </div>
      )}

      {subPhase === 'ORDERS' && (
        <div className="flex flex-col items-center w-full max-w-2xl">
           <div className="bg-white p-8 rounded-2xl shadow-2xl border-4 border-yellow-400 w-full text-center relative">
              <div className="absolute -top-6 left-1/2 -translate-x-1/2 bg-yellow-400 text-white font-bold px-6 py-2 rounded-full font-pixel text-xl shadow-lg border-2 border-white">
                 ĐƠN HÀNG {currentOrderIndex + 1}/{orders.length}
              </div>

              <div className="mt-6 mb-6 flex justify-center animate-bounce">
                 <div className="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center border-4 border-gray-200">
                    {orders[currentOrderIndex].icon}
                 </div>
              </div>

              <h3 className="text-2xl font-bold text-gray-800 mb-2">{orders[currentOrderIndex].customer}</h3>
              <p className="text-gray-600 italic mb-8">"{orders[currentOrderIndex].dialogue}"</p>

              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                 {PRODUCTS.map(p => (
                   <button
                     key={p.type}
                     onClick={() => handleOrderSubmit(p.type)}
                     className={`p-3 rounded-xl font-bold text-sm shadow-sm hover:shadow-md transform hover:-translate-y-1 transition-all ${p.color} border border-black/5`}
                   >
                     {p.label}
                   </button>
                 ))}
              </div>
           </div>
        </div>
      )}
      
      {feedback && (
        <div className="mt-6 px-6 py-3 bg-gray-800 text-white rounded-full font-bold animate-pulse">
          {feedback}
        </div>
      )}

    </div>
  );
};